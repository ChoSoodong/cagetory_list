




#ifndef UIKitHeader_h
#define UIKitHeader_h







//#import "UIViewController+TopBarMessage.h"

#import "UIViewController+Alert.h"

#import "UIViewController+Visible.h"

#import "UIViewController+HHTransition.h"
#import "UIView+HHLayout.h"

#import "UIView+Indicator.h"
#import "UIView+Radius.h"
#import "SDShadowView.h"
#import "UIView+BlockGesture.h"


#import "UIScrollView+SimpleScroll.h"
#import "UIScrollView+Frame.h"


#import "UIButton+BackgroundColor.h"
#import "UIButton+Block.h"
#import "UIButton+CountDown.h"
#import "UIButton+Indicator.h"
//#import "UIButton+ClickEdgeInsets.h"
#import "UIButton+Submitting.h"
#import "UIButton+ImagePosition.h"
//#import "UIButton+Badge.h"
#import "UIButton+Addition.h"
#import "UIButton+Setting.h"
#import "ScrollTopButton.h"







#import "UILabel+Space.h"
#import "UILabel+Addition.h"
#import "UILabel+AttributedString.h"
#import "UILabel+Line.h"
#import "YYFPSLabel.h"
#import "SDClipboardLabel.h"
#import "UILabel+AttributedTextColor.h"



#import "UIView+Toast.h"
#import "UIView+Frame.h"
//#import "UIView+Screenshot.h"
//#import "UIView+Animation.h"
//#import "UIView+Border.h"
//#import "UIView+Find.h"
//#import "UIView+BlockGesture.h"
#import "UIView+ViewController.h"
#import "UIView+Shake.h"
//#import "UIView+Badge.h"
#import "UIView+DrawCategory.h"
#import "UIView+Make.h"


#import "UIImage+Color.h"
#import "UIImage+GIF.h"
#import "UIImage+Compress.h"
#import "UIImage+Video.h"
#import "UIImage+FileName.h"
#import "UIImage+CircleImage.h"
#import "UIImage+QRCode.h"
#import "UIImage+URL.h"



#import "UIImageView+Download.h"
#import "UIImageView+Addition.h"



#import "UIFont+FontSize.h"

//#import "UIApplication+AppInfo.h"



#import "UIColor+Gradient.h"
#import "UIColor+HEX.h"
#import "UIColor+Addition.h"


#import "UITextField+InputLimit.h"
#import "UITextField+Addition.h"



#import "UIAlertController+Alert.h"

#import "UITextView+PlaceHolder.h"
#import "UITextView+InputLimit.h"
#import "UITextView+Create.h"

#endif
