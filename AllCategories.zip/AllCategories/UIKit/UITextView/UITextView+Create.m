







#import "UITextView+Create.h"


@implementation UITextView (Create)

+(instancetype)textViewWithBackgroundColor:(UIColor *)backgroundColor TextColor:(UIColor *)textColor text:(NSString *)text placeholderColor:(UIColor *)placeholderColor placeholder:(NSString *)placeholder font:(CGFloat)font maxLength:(NSInteger)maxLength editable:(BOOL)editable{
    
    UITextView *textView = [[UITextView alloc] init];
    //背景色
    textView.backgroundColor = backgroundColor;
    //文本
    textView.text = text;
    //字体
    textView.font = [UIFont systemFontOfSize:font];
    //对齐
    //textView.textAlignment = NSTextAlignmentCenter;
    //字体颜色
    textView.textColor = textColor;
    //占位文字颜色
    textView.placeholderColor = placeholderColor;
    //占位文字
    textView.placeholder = placeholder;
    //最大输入文字个数 小于等于0就是没限制
    textView.maxLength = maxLength;
    
    //是否允许编辑
    textView.editable = editable;
//    //用户交互     ///////若想有滚动条 不能交互 上为No，下为Yes
//    textView.userInteractionEnabled = YES; ///
//    //自定义键盘
//    //textView.inputView = view;//自定义输入区域
//    //textView.inputAccessoryView = view;//键盘上加view
//
//    textView.scrollEnabled = YES;//滑动
//    textView.returnKeyType = UIReturnKeyDone;//返回键类型
//    textView.keyboardType = UIKeyboardTypeDefault;//键盘类型
//    textView.autoresizingMask = UIViewAutoresizingFlexibleHeight;//自适应
//    textView.dataDetectorTypes = UIDataDetectorTypeAll;//数据类型连接模式
//    textView.autocorrectionType = UITextAutocorrectionTypeNo;//自动纠错方式
//    textView.autocapitalizationType = UITextAutocapitalizationTypeNone;//自动大写方式
    
    return textView;
}


@end
