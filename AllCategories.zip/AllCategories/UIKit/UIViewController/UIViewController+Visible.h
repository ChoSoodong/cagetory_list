








#import <UIKit/UIKit.h>

@interface UIViewController (Visible)

- (BOOL)isVisible;

@end
