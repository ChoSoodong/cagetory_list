








#import "UIViewController+Visible.h"

@implementation UIViewController (Visible)

- (BOOL)isVisible {
    return [self isViewLoaded] && self.view.window;
}

@end
