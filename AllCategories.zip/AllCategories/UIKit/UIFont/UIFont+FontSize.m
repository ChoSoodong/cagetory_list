//
//  UIFont+FontSize.m
//  KoreanPetApp
//
//  Created by xialan on 2018/11/22.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import "UIFont+FontSize.h"

#define MyUIScreen  375 // UI设计原型图的手机尺寸宽度(6), 6p的--414


@implementation UIFont (FontSize)




+ (CGFloat)adjustFontSize:(CGFloat)fontsize {
    CGFloat newFont;
    if (IS_IPHONE_5) {
        newFont = fontsize - IPHONE5_INCREMENT;
    } else if (IS_IPHONE_6) {
        newFont = fontsize;
    } else if (IS_IPHONE_6PLUS) {
        newFont = fontsize + IPHONE6PLUS_INCREMENT;
    } else if (IS_IPHONE_X_ALL) {
        newFont = fontsize + IS_IPHONEX_INCREMENT;
    } else {
        newFont = fontsize - IPHONE5_INCREMENT;
    }
    return newFont;
}

@end
