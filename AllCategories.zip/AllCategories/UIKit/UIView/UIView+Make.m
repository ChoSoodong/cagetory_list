//
//  UIView+Make.m
//  Dwelling
//
//  Created by xialan on 2019/9/20.
//  Copyright © 2019 xialan. All rights reserved.
//

#import "UIView+Make.h"

@implementation UIView (Make)

+(instancetype)viewWithBackgroundColor:(UIColor *)color{
    
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = color;
    
    return view;
    
}


@end
