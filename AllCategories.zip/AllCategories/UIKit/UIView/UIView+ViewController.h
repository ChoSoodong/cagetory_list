








#import <UIKit/UIKit.h>

@interface UIView (ViewController)

/// 所在的ViewController
- (UIViewController *)viewController ;

@end
