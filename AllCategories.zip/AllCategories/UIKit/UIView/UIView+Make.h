//
//  UIView+Make.h
//  Dwelling
//
//  Created by xialan on 2019/9/20.
//  Copyright © 2019 xialan. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Make)

+(instancetype)viewWithBackgroundColor:(UIColor *)color;

@end

NS_ASSUME_NONNULL_END
