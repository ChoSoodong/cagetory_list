//
//  UIView+Indicator.h
//  KoreanPetApp
//
//  Created by xialan on 2018/12/3.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Indicator)

/// 显示菊花
- (void)showIndicator;

/// 隐藏菊花
- (void)hideIndicator;

@end

NS_ASSUME_NONNULL_END
