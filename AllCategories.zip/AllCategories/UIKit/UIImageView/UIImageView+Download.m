







#import "UIImageView+Download.h"
#import "UIImage+CircleImage.h"
#import <SDWebImage/SDWebImage.h>


typedef void (^completionCallback)(UIImage *localImage,RHNetworkStatus internetStatus);

@implementation UIImageView (Download)

#pragma mark - 内部方法 从子线程中读取图片 判断网络
-(void)getLocalImageWithUrl:(NSString *)imageUrl completion:(completionCallback)completion{
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        //从子线程中执行 获取当前网络状况
        Reachability *reachability   = [Reachability reachabilityWithHostName:@"www.baidu.com"];
        RHNetworkStatus internetStatus = [reachability currentReachabilityStatus];
        
        //从子线程中执行 读取图片的操作
        UIImage *originImage = [[SDImageCache sharedImageCache] imageFromDiskCacheForKey:imageUrl];
        
        // 图片下载完成之后,回到主线程更新UI
        dispatch_async(dispatch_get_main_queue(), ^{
            // 设置图片视图
            completion(originImage,internetStatus);
            
        });
    });
    
}


- (void)sd_setOriginImage:(NSString *)originImageURL thumbnailImage:(NSString *)thumbnailImageURL downloadOriginImageWhenWWAN:(BOOL)isDownloadOriginImage placeholder:(UIImage *)placeholder{
    
    
    [self getLocalImageWithUrl:originImageURL completion:^(UIImage *localImage, RHNetworkStatus internetStatus) {
        
        if (localImage) {
            self.image = localImage;
        }else{
            
            if (internetStatus == ReachableViaWiFi) {
                [self sd_setImageWithURL:[NSURL URLWithString:originImageURL] placeholderImage:placeholder];
            } else if (internetStatus == ReachableViaWWAN) {
                // 3G\4G网络下时候要下载原图
                if (isDownloadOriginImage) {
                    [self sd_setImageWithURL:[NSURL URLWithString:originImageURL] placeholderImage:placeholder];
                } else {
                    [self sd_setImageWithURL:[NSURL URLWithString:thumbnailImageURL] placeholderImage:placeholder];
                }
            } else { // 没有可用网络
                UIImage *thumbnailImage = [[SDImageCache sharedImageCache] imageFromDiskCacheForKey:thumbnailImageURL];
                if (thumbnailImage) { // 缩略图已经被下载过
                    self.image = thumbnailImage;
                } else { // 没有下载过任何图片
                    // 占位图片;
                    self.image = placeholder;
                }
            }
            
        }
        
        
    }];
   
  
    
//    // 根据网络状态来加载图片
//    // 获得原图（SDWebImage的图片缓存是用图片的url字符串作为key）
//    UIImage *originImage = [[SDImageCache sharedImageCache] imageFromDiskCacheForKey:originImageURL];
//    if (originImage) { // 原图已经被下载过
//        self.image = originImage;
//    } else { // 原图并未下载过
//        if (internetStatus == ReachableViaWiFi) {
//            [self sd_setImageWithURL:[NSURL URLWithString:originImageURL] placeholderImage:placeholder];
//        } else if (internetStatus == ReachableViaWWAN) {
//            // 3G\4G网络下时候要下载原图
//            if (isDownloadOriginImage) {
//                [self sd_setImageWithURL:[NSURL URLWithString:originImageURL] placeholderImage:placeholder];
//            } else {
//                [self sd_setImageWithURL:[NSURL URLWithString:thumbnailImageURL] placeholderImage:placeholder];
//            }
//        } else { // 没有可用网络
//            UIImage *thumbnailImage = [[SDImageCache sharedImageCache] imageFromDiskCacheForKey:thumbnailImageURL];
//            if (thumbnailImage) { // 缩略图已经被下载过
//                self.image = thumbnailImage;
//            } else { // 没有下载过任何图片
//                // 占位图片;
//                self.image = placeholder;
//            }
//        }
//    }
    
}

- (void)sd_setOriginImage:(NSString *)originImageURL thumbnailImage:(NSString *)thumbnailImageURL downloadOriginImageWhenWWAN:(BOOL)isDownloadOriginImage placeholder:(UIImage *)placeholder completed:(nullable SDExternalCompletionBlock)completedBlock{
    
    
    [self getLocalImageWithUrl:originImageURL completion:^(UIImage *localImage, RHNetworkStatus internetStatus) {
        
        if (localImage) { // 原图已经被下载过
            self.image = localImage;
            completedBlock(localImage, nil, 0, [NSURL URLWithString:originImageURL]);
        } else { // 原图并未下载过
            if (internetStatus == ReachableViaWiFi) {
                [self sd_setImageWithURL:[NSURL URLWithString:originImageURL] placeholderImage:placeholder completed:completedBlock];
            } else if (internetStatus == ReachableViaWWAN) {
                // 3G\4G网络下时候要下载原图
                if (isDownloadOriginImage) {
                    [self sd_setImageWithURL:[NSURL URLWithString:originImageURL] placeholderImage:placeholder completed:completedBlock];
                } else {
                    [self sd_setImageWithURL:[NSURL URLWithString:thumbnailImageURL] placeholderImage:placeholder completed:completedBlock];
                }
            } else { // 没有可用网络
                UIImage *thumbnailImage = [[SDImageCache sharedImageCache] imageFromDiskCacheForKey:thumbnailImageURL];
                if (thumbnailImage) { // 缩略图已经被下载过
                    self.image = thumbnailImage;
                    completedBlock(thumbnailImage, nil, 0, [NSURL URLWithString:thumbnailImageURL]);
                } else { // 没有下载过任何图片
                    // 占位图片;
                    self.image = placeholder;
                }
            }
        }
    }];
    
}


- (void)sd_setCircleAvatar:(NSString *)avatarURL placeholder:(UIImage *)placeholder{


    [self sd_setImageWithURL:[NSURL URLWithString:avatarURL] placeholderImage:placeholder options:0 completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        // 图片下载失败，直接返回，按照它的默认做法
        if (!image) return;
        
        [image circleImageWithCompletion:^(UIImage *completeImage) {
            self.image = completeImage;
        }];
        
        
    }];
    
    
}



- (void)sd_setCornerRadiusImage:(NSString *)imageURL cornerRadius:(CGFloat)radius placeholder:(UIImage *)placeholder{
    
    
    //带圆角的image
    //圆形头像
    [self sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:placeholder options:0 completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
        // 图片下载失败，直接返回，按照它的默认做法
        if (!image) return;
        
        [image drawCornerRadiusWithRadius:radius completion:^(UIImage *completeImage) {
            
            self.image = completeImage;
        }];
        
    }];
    

}



@end
