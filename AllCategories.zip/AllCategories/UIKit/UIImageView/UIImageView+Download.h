







#import <UIKit/UIKit.h>
#import <UIImageView+WebCache.h>



@interface UIImageView (Download)

/**
  根据网络状况设置图片

 @param originImageURL 大图URL字符串
 @param thumbnailImageURL 缩略图URL字符串
 @param isDownloadOriginImage 非wifi网络下,是否下载原图  [downloadOriginImageWhenWWAN配置项的值需要从沙盒里面获取]
 @param placeholder 占位图
 @param completedBlock 图片下载完成回调
 */
//SDExternalCompletionBlock
- (void)sd_setOriginImage:(NSString *)originImageURL thumbnailImage:(NSString *)thumbnailImageURL downloadOriginImageWhenWWAN:(BOOL)isDownloadOriginImage placeholder:(UIImage *)placeholder completed:(nullable SDExternalCompletionBlock)completedBlock;


/**
 根据网络状况设置图片
 
 @param originImageURL 大图URL字符串
 @param thumbnailImageURL 缩略图URL字符串
 @param isDownloadOriginImage 非wifi网络下,是否下载原图  [downloadOriginImageWhenWWAN配置项的值需要从沙盒里面获取]
 @param placeholder 占位图
 */
- (void)sd_setOriginImage:(NSString *)originImageURL thumbnailImage:(NSString *)thumbnailImageURL downloadOriginImageWhenWWAN:(BOOL)isDownloadOriginImage placeholder:(UIImage *)placeholder;


/**
 根据头像URL 设置圆形头像

 @param avatarURL 头像 URL
 @param placeholder 占位图
 */
- (void)sd_setCircleAvatar:(NSString *)avatarURL placeholder:(UIImage *)placeholder;




/**
 根据图片url 切圆角

 @param imageURL 图片url
 @param radius 圆角半径 0.5是圆形 小于0.5 是带圆角的矩形 大于0.5是椭圆
 @param placeholder 占位图
 */
- (void)sd_setCornerRadiusImage:(NSString *)imageURL cornerRadius:(CGFloat)radius placeholder:(UIImage *)placeholder;

@end
