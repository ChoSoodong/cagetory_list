//
//  UIImageView+Addition.h
//  AlphaPay
//
//  Created by xialan on 2019/2/16.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImageView (Addition)

/** 创建UIImageView */
+(instancetype)imageViewWithFrame:(CGRect)frame
                           imageName:(NSString *)imageName
                         contentMode:(UIViewContentMode)contentMode;


/** 创建UIImageView */
+(instancetype)imageViewWithFrame:(CGRect)frame
                        imageName:(NSString *)imageName;


@end

NS_ASSUME_NONNULL_END
