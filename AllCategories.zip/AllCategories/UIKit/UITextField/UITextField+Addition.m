//
//  UITextField+Addition.m
//  TryToHARAM
//
//  Created by xialan on 2018/10/19.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import "UITextField+Addition.h"

@implementation UITextField (Addition)

#pragma mark - 抽取创建TextField方法
+(instancetype)textFieldWithTextColor:(UIColor *)textColor font:(CGFloat)font secureTextEntry:(BOOL)isSecureText placeholder:(NSString *)holderText placeholderColor:(UIColor *)placeholderColor keyboardType:(UIKeyboardType)keyboardType clearButtonImageName:(NSString *)clearImageName leftImageName:(NSString *)imageName{
    
    UITextField *textField = [[self alloc] init];
    //背景色
    textField.backgroundColor = [UIColor clearColor];
    //输入文字的颜色
    textField.textColor = textColor;
    //占位文字的颜色
    NSAttributedString *attrString = [[NSAttributedString alloc] initWithString:holderText attributes:@{NSForegroundColorAttributeName:placeholderColor,NSFontAttributeName:textField.font}];
    textField.attributedPlaceholder = attrString;
    //字体
    textField.font = [UIFont systemFontOfSize:font];
    //是否为安全输入
    textField.secureTextEntry = isSecureText;
    //键盘类型
    textField.keyboardType = keyboardType;
    
    //是否有左边的图片
    if (imageName != nil && ![imageName isEqualToString:@""]) {
        //左边的图片
        UIImageView *ImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 40, 34)];
        ImgView.image = [UIImage imageNamed:imageName];
        ImgView.contentMode = UIViewContentModeCenter;
        ImgView.clipsToBounds = YES;
        textField.leftView = ImgView;
        
    }else{
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 15, 35)];
        view.backgroundColor = [UIColor clearColor];
        textField.leftView = view;
    }
    textField.leftViewMode=UITextFieldViewModeAlways;
    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    //是否需要自定义清除按钮
    if (clearImageName != nil && ![clearImageName isEqualToString:@""]) {
        //自定义清除按钮
        UIButton *button = [textField valueForKey:@"_clearButton"];
        [button setImage:[UIImage imageNamed:clearImageName] forState:UIControlStateNormal];
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    }
   
    
    return textField;
}

#pragma mark - 抽取创建TextField方法
+(instancetype)textFieldWithTextColor:(UIColor *)textColor font:(CGFloat)font secureTextEntry:(BOOL)isSecureText placeholder:(NSString *)holderText placeholderColor:(UIColor *)placeholderColor keyboardType:(UIKeyboardType)keyboardType{
    
    UITextField *textField = [[self alloc] init];
    //背景色
    textField.backgroundColor = [UIColor clearColor];
    //输入文字的颜色
    textField.textColor = textColor;
    //占位文字的颜色
    NSAttributedString *attrString = [[NSAttributedString alloc] initWithString:holderText attributes:@{NSForegroundColorAttributeName:placeholderColor,NSFontAttributeName:textField.font}];
    textField.attributedPlaceholder = attrString;
    //字体
    textField.font = [UIFont systemFontOfSize:font];
    //是否为安全输入
    textField.secureTextEntry = isSecureText;
    //键盘类型
    textField.keyboardType = keyboardType;
    
    
    textField.leftViewMode=UITextFieldViewModeAlways;
    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    
    
    return textField;
}



@end
