








#import <UIKit/UIKit.h>

@interface UITextField (InputLimit)

@property (assign, nonatomic)  NSInteger maxLength ; // <= 0无限制

@end
