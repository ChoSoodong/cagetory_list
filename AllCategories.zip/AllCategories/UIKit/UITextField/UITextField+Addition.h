//
//  UITextField+Addition.h
//  TryToHARAM
//
//  Created by xialan on 2018/10/19.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UITextField (Addition)


/**
 快速创建TextField

 @param textColor 输入文字的颜色
 @param font 字体
 @param isSecureText 是否为安全输入
 @param holderText 占位文字
 @param placeholderColor 占位文字颜色
 @param keyboardType  键盘类型
 @param clearImageName 右侧清除按钮图片名称
 @param imageName 左侧图片名称
 @return textfield
 */
+(instancetype)textFieldWithTextColor:(UIColor *)textColor font:(CGFloat)font secureTextEntry:(BOOL)isSecureText placeholder:(NSString *)holderText placeholderColor:(UIColor *)placeholderColor keyboardType:(UIKeyboardType)keyboardType clearButtonImageName:(NSString *)clearImageName leftImageName:(NSString *)imageName;


+(instancetype)textFieldWithTextColor:(UIColor *)textColor font:(CGFloat)font secureTextEntry:(BOOL)isSecureText placeholder:(NSString *)holderText placeholderColor:(UIColor *)placeholderColor keyboardType:(UIKeyboardType)keyboardType;

@end

