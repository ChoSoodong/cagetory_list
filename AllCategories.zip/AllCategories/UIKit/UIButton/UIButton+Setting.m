//
//  UIButton+Setting.m
//  KoreanPetApp
//
//  Created by xialan on 2018/11/23.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import "UIButton+Setting.h"

@implementation UIButton (Setting)

-(void)setNormalTitle:(NSString *)normalTitle titleColor:(UIColor *)titleColor{
    
    [self setTitle:normalTitle forState:UIControlStateNormal];
    [self setTitleColor:titleColor forState:UIControlStateNormal];
}

-(void)setHighlightedTitle:(NSString *)highlightedTitle titleColor:(UIColor *)titleColor{
    
    [self setTitle:highlightedTitle forState:UIControlStateHighlighted];
    [self setTitleColor:titleColor forState:UIControlStateHighlighted];
}

-(void)setSelectedTitle:(NSString *)selectedTitle titleColor:(UIColor *)titleColor{
    [self setTitle:selectedTitle forState:UIControlStateSelected];
    [self setTitleColor:titleColor forState:UIControlStateSelected];
}

-(void)setDisabledTitle:(NSString *)disabledTitle titleColor:(UIColor *)titleColor{
    [self setTitle:disabledTitle forState:UIControlStateDisabled];
    [self setTitleColor:titleColor forState:UIControlStateDisabled];
}


-(void)setNormalImage:(NSString *)normalImage{
    
    [self setImage:[UIImage imageNamed:normalImage] forState:UIControlStateNormal];
}
-(void)setHighlightedImage:(NSString *)highlightedImage {

    [self setImage:[UIImage imageNamed:highlightedImage] forState:UIControlStateHighlighted];

}
-(void)setSelectedImage:(NSString *)selectedImage{
    [self setImage:[UIImage imageNamed:selectedImage] forState:UIControlStateSelected];
}
-(void)setDisabledImage:(NSString *)disabledImage{
    [self setImage:[UIImage imageNamed:disabledImage] forState:UIControlStateDisabled];
}


//设置背景图片
-(void)setNormalBackgroundImage:(NSString *)normalImage{
    [self setBackgroundImage:[UIImage imageNamed:normalImage] forState:UIControlStateNormal];
}
-(void)setHighlightedBackgroundImage:(NSString *)highlightedImage{
    [self setBackgroundImage:[UIImage imageNamed:highlightedImage] forState:UIControlStateHighlighted];
}
-(void)setSelectedBackgroundImage:(NSString *)selectedImage{
    [self setBackgroundImage:[UIImage imageNamed:selectedImage] forState:UIControlStateSelected];
}
-(void)setDisabledBackgroundImage:(NSString *)disabledImage{
    [self setBackgroundImage:[UIImage imageNamed:disabledImage] forState:UIControlStateDisabled];
}

@end
