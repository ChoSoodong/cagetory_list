



#import <UIKit/UIKit.h>

typedef void (^TouchedBlock)(id sender);
@interface UIButton (Block)

/// 给点击状态添加事件
-(void)addActionHandler:(TouchedBlock)touchHandler;

@end
