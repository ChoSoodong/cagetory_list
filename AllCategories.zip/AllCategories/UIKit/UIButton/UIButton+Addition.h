//
//  UIButton+Addition.h
//  TryToHARAM
//
//  Created by xialan on 2018/10/19.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface UIButton (Addition)


/**
 创建只有文字的按钮

 @param title 标题
 @param titleColor 文字颜色
 @param font 字号
 @return button
 */
+(instancetype)buttonWithTitle:(NSString *)title titleColor:(UIColor *)titleColor font:(CGFloat)font;


/**
 创建只有图片的按钮

 @param hl_imageName 高亮图片名称
 @param nor_imageName 图片名称
 @return button
 */
+(instancetype)buttonWithHighlightImageName:(NSString *)hl_imageName normalImageName:(NSString *)nor_imageName;

/**
 创建只有图片的按钮
 
 @param sel_imageName 选中图片名称
 @param nor_imageName 图片名称
 @return button
 */
+(instancetype)buttonWithSelectedImageName:(NSString *)sel_imageName normalImageName:(NSString *)nor_imageName;

/**
 快速创建 高亮状态的button

 @param hl_title 高亮状态标题
 @param hl_color 高亮状态标题颜色
 @param hl_imageName 高亮状态图片名称
 @param hl_bgImageName 高亮状态背景图片名称
 @param nor_title 普通状态标题
 @param nor_color 普通状态标题颜色
 @param nor_imageName 普通状态图片名称
 @param nor_bgImageName 普通状态背景图片名称
 @param font 字体
 @return button
 */
+(instancetype)buttonWithHighlightedTitle:(NSString *)hl_title highlightColor:(UIColor *)hl_color highlightImageName:(NSString *)hl_imageName highlightBackgroundImageName:(NSString *)hl_bgImageName normalTitle:(NSString *)nor_title normalColor:(UIColor *)nor_color normalImageName:(NSString *)nor_imageName normalBackgroundImageName:(NSString *)nor_bgImageName font:(CGFloat)font;




/**
 快速创建 选中状态的button

 @param sel_title 选中状态标题
 @param sel_color 选中状态标题颜色
 @param sel_imageName 选中状态图片名称
 @param sel_bgImageName 选中状态背景图片名称
 @param nor_title 普通状态标题
 @param nor_color 普通状态标题颜色
 @param nor_imageName 普通状态图片名称
 @param nor_bgImageName 普通状态背景图片名称
 @param font 字体
 @return button
 */
+(instancetype)buttonWithSelectedTitle:(NSString *)sel_title selectedColor:(UIColor *)sel_color selectedImageName:(NSString *)sel_imageName selectedBackgroundImageName:(NSString *)sel_bgImageName normalTitle:(NSString *)nor_title normalColor:(UIColor *)nor_color normalImageName:(NSString *)nor_imageName normalBackgroundImageName:(NSString *)nor_bgImageName font:(CGFloat)font;

@end


