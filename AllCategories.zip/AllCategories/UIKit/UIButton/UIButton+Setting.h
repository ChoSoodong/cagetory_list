//
//  UIButton+Setting.h
//  KoreanPetApp
//
//  Created by xialan on 2018/11/23.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (Setting)

//设置文字
-(void)setNormalTitle:(NSString *)normalTitle titleColor:(UIColor *)titleColor;
-(void)setHighlightedTitle:(NSString *)highlightedTitle titleColor:(UIColor *)titleColor;
-(void)setSelectedTitle:(NSString *)selectedTitle titleColor:(UIColor *)titleColor;
-(void)setDisabledTitle:(NSString *)disabledTitle titleColor:(UIColor *)titleColor;


//设置图片
-(void)setNormalImage:(NSString *)normalImage;
-(void)setHighlightedImage:(NSString *)highlightedImage;
-(void)setSelectedImage:(NSString *)selectedImage;
-(void)setDisabledImage:(NSString *)disabledImage;

//设置背景图片
-(void)setNormalBackgroundImage:(NSString *)normalImage;
-(void)setHighlightedBackgroundImage:(NSString *)highlightedImage;
-(void)setSelectedBackgroundImage:(NSString *)selectedImage;
-(void)setDisabledBackgroundImage:(NSString *)disabledImage;


@end

NS_ASSUME_NONNULL_END
