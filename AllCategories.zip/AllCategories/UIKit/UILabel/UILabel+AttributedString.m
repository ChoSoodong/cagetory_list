//
//  UILabel+AttributedString.m
//  TasteFresh
//
//  Created by ZHAO on 2018/1/12.
//  Copyright © 2018年 XiaLanTech. All rights reserved.
//

#import "UILabel+AttributedString.h"

@implementation UILabel (AttributedString)

-(void)setText:(NSString *)text frontImages:(NSArray<UIImage *> *)images imageSpan:(CGFloat)span
{
    NSMutableAttributedString *textAttrStr = [[NSMutableAttributedString alloc] init];
    
    for (UIImage *img in images) {//遍历添加标签
        
        NSTextAttachment *attach = [[NSTextAttachment alloc] init];
        attach.image = img;
        //计算图片大小，与文字同高，按比例设置宽度
        CGFloat imgH = self.font.pointSize;
        CGFloat imgW = (img.size.width / img.size.height) * imgH;
        //计算文字padding-top ，使图片垂直居中
        CGFloat textPaddingTop = (self.font.lineHeight - self.font.pointSize) / 2;
        attach.bounds = CGRectMake(0, -textPaddingTop , imgW, imgH);
        
        NSAttributedString *imgStr = [NSAttributedString attributedStringWithAttachment:attach];
        [textAttrStr appendAttributedString:imgStr];
        //标签后添加空格
        [textAttrStr appendAttributedString:[[NSAttributedString alloc] initWithString:@" "]];
    }
    
    //设置显示文本
    [textAttrStr appendAttributedString:[[NSAttributedString alloc]initWithString:text]];
    //设置间距
    if (span != 0) {
        [textAttrStr addAttribute:NSKernAttributeName value:@(span)
                            range:NSMakeRange(0, images.count * 2/*由于图片也会占用一个单位长度,所以带上空格数量，需要 *2 */)];
    }
    
    self.attributedText = textAttrStr;
}


-(void)setText:(NSString *)Text frontFont:(CGFloat)frontFont behindFont:(CGFloat)behindFont textColor:(UIColor *)textColor{
    
    //分隔字符串
    NSString *lastStr;
    NSString *firstStr;
    
    if ([Text containsString:@"."]) {
        NSRange range = [Text rangeOfString:@"."];
        lastStr = [Text substringFromIndex:range.location];
        firstStr = [Text substringToIndex:range.location];
    }

    NSMutableAttributedString *AttributedStr = [[NSMutableAttributedString alloc] initWithString:Text];
    
    //小数点前面的字体大小
    [AttributedStr addAttribute:NSFontAttributeName
                          value:[UIFont boldSystemFontOfSize:frontFont]
                          range:NSMakeRange(0, firstStr.length)];
    
    //小数点后面的字体大小
    [AttributedStr addAttribute:NSFontAttributeName
                          value:[UIFont boldSystemFontOfSize:behindFont]
                          range:NSMakeRange(firstStr.length, lastStr.length)];
    //字符串的颜色
    [AttributedStr addAttribute:NSForegroundColorAttributeName
                          value:textColor
                          range:NSMakeRange(0, Text.length)];
    
    self.attributedText = AttributedStr;
}





@end
