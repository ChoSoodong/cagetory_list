//
//  UILabel+Line.h
//  KoreanPetApp
//
//  Created by xialan on 2018/11/5.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger,LinePositionType){
    LinePositionMiddle = 0, //中划线
    LinePositionBottom      //下划线
};


@interface UILabel (Line)


/**
 全部文字设置 中划线或下划线

 @param positionType 位置
 @return label
 */
-(instancetype)setDeleteLinePosition:(LinePositionType)positionType;



/**
 给指定的文字设置 中划线或下划线

 @param positionType 线的位置
 @param lineText 要设置线的文字
 @return label
 */
-(instancetype)setDeleteLinePosition:(LinePositionType)positionType andText:(NSString *)lineText;


@end


