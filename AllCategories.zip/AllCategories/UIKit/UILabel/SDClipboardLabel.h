//
//  SDClipboardLabel.h
//  AlphaPay
//
//  Created by xialan on 2019/2/16.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import <UIKit/UIKit.h>

//长按复制label

@interface SDClipboardLabel : UILabel

@property (nonatomic, assign) BOOL copyEnabled;

@end


