//
//  SDClipboardLabel.m
//  AlphaPay
//
//  Created by xialan on 2019/2/16.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import "SDClipboardLabel.h"

@interface SDClipboardLabel ()

@property (nonatomic, strong) UILongPressGestureRecognizer *longPressGR;

@end

@implementation SDClipboardLabel

- (void)setCopyEnabled:(BOOL)copyEnabled
{
    _copyEnabled = copyEnabled;
    
    self.userInteractionEnabled = copyEnabled;
    if (copyEnabled) {
        if (!self.longPressGR) {
            self.longPressGR = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPressGesture:)];
            [self addGestureRecognizer:self.longPressGR];
        }
    } else {
        if (self.longPressGR) {
            [self removeGestureRecognizer:self.longPressGR];
        }
    }
}

- (BOOL)canBecomeFirstResponder
{
    return YES;
}

- (BOOL)canPerformAction:(SEL)action
              withSender:(id)sender
{
    return (action == @selector(copy:));
}

#pragma mark - Actions

- (void)handleLongPressGesture:(UILongPressGestureRecognizer *)recognizer
{
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        [recognizer.view becomeFirstResponder];
        UIMenuController *menuController = [UIMenuController sharedMenuController];
        [menuController setTargetRect:recognizer.view.frame inView:recognizer.view.superview];
        [menuController setMenuVisible:YES animated:YES];
    }
}

#pragma mark - UIResponderStandardEditActions

- (void)copy:(id)sender
{
    [[UIPasteboard generalPasteboard] setString:self.text];
}

@end
