







#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UILabel (AttributedTextColor)


/**
 给label中指定的文字设置颜色

 @param targetColor 指定的颜色
 @param targetText 指定的文字
 @return label
 */
-(instancetype)setTargetTextColor:(UIColor *)targetColor andTargetText:(NSString *)targetText;


/**
 给label中指定的文字设置字体

 @param targetFont 加粗的字体
 @param targetText 指定的文字
 @return label
 */
-(instancetype)setTargetTextFont:(CGFloat)targetFont andTargetText:(NSString *)targetText;

@end

NS_ASSUME_NONNULL_END
