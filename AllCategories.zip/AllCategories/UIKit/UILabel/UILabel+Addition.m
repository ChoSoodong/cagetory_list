//
//  UILabel+Addition.m
//
//
//
//
//

#import "UILabel+Addition.h"

@implementation UILabel (Addition)
+ (instancetype)labelWithTextColor:(UIColor *)color andTextFontSize:(CGFloat)fontSize andNumblerOfLines:(NSInteger)lines andText:(NSString *)text {
    
    UILabel *label = [[self alloc] init];
    label.text = text;
    label.textColor = color;
    // 设置字体"默认字体17号"
    label.font = [UIFont systemFontOfSize:fontSize];
    //行数
    label.numberOfLines = lines;
    
    return label;
}


+ (instancetype)labelWithFrame:(CGRect)frame TextColor:(UIColor *)color andTextFontSize:(CGFloat)fontSize andNumblerOfLines:(NSInteger)lines andText:(NSString *)text {
    
    UILabel *label = [[self alloc] initWithFrame:frame];
    label.text = text;
    label.textColor = color;
    // 设置字体"默认字体17号"
    label.font = [UIFont systemFontOfSize:fontSize];
    //行数
    label.numberOfLines = lines;
    
    return label;
}


+ (instancetype)labelWithTextColor:(UIColor *)color boldFontSize:(CGFloat)boldfontSize numblerOfLines:(NSInteger)lines text:(NSString *)text {
    
    UILabel *label = [[self alloc] init];
    label.text = text;
    label.textColor = color;
    // 设置字体"默认字体17号"
    label.font = [UIFont boldSystemFontOfSize:boldfontSize];
    //行数
    label.numberOfLines = lines;
    
    return label;
}

@end
