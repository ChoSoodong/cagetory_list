//
//  UILabel+Line.m
//  KoreanPetApp
//
//  Created by xialan on 2018/11/5.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import "UILabel+Line.h"

@implementation UILabel (Line)

-(instancetype)setDeleteLinePosition:(LinePositionType)positionType{
    
    //中划线
    if (positionType == LinePositionMiddle) {
        
        //中划线
        NSDictionary *attribtDic = @{NSStrikethroughStyleAttributeName: [NSNumber numberWithInteger:NSUnderlineStyleSingle]};
        NSMutableAttributedString *attribtStr = [[NSMutableAttributedString alloc]initWithString:self.text attributes:attribtDic];
        
        // 赋值
        self.attributedText = attribtStr;
        
        return self;
        
    //下划线
    }else if(positionType == LinePositionBottom){
        
        // 下划线
        NSDictionary *attribtDic = @{NSUnderlineStyleAttributeName: [NSNumber numberWithInteger:NSUnderlineStyleSingle]};
        NSMutableAttributedString *attribtStr = [[NSMutableAttributedString alloc]initWithString:self.text attributes:attribtDic];
        
        // 赋值
        self.attributedText = attribtStr;
        
        return self;
        
    }else{
        
        return self;
    }
}

-(instancetype)setDeleteLinePosition:(LinePositionType)positionType andText:(NSString *)lineText{
    
    if (lineText.length > self.text.length) return self;
    
    //中划线
    if (positionType == LinePositionMiddle) {
        
        //中划线
        NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:self.text];
        
        NSRange range = [self.text rangeOfString:lineText];
        [attrString addAttribute:NSStrikethroughStyleAttributeName
                           value:@(NSUnderlineStyleSingle)
                           range:range];
        
        // 赋值
        self.attributedText = attrString;
        
        return self;
        
        //下划线
    }else if(positionType == LinePositionBottom){
        
        // 下划线
        NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:self.text];
        
        NSRange range = [self.text rangeOfString:lineText];
        [attrString addAttribute:NSUnderlineStyleAttributeName
                           value:@(NSUnderlineStyleSingle)
                           range:range];
        
        // 赋值
        self.attributedText = attrString;
        
        return self;
        
    }else{
        
        return self;
    }
}

@end
