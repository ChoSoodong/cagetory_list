








#import <UIKit/UIKit.h>

@interface UIImage (Video)

/// 获取视频的截图信息
+ (UIImage *)imageWithVideo:(NSString *)stringURL;

@end
