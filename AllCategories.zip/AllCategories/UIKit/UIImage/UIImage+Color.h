








#import <UIKit/UIKit.h>


@interface UIImage (Color)

/**
 生成纯色图片

 @param color Color
 @param size Size
 @return 纯色图片
 */
+ (UIImage *)imageWithColor:(UIColor *)color withSize:(CGSize)size ;

/**
 生成一个像素点的纯色图片

 @param color Color
 @return 纯色图片
 */
+ (UIImage *)imageWithColor:(UIColor *)color ;

/**
 在某个点的颜色

 @param point 点
 @return 颜色
 */
- (UIColor *)colorAtPoint:(CGPoint )point ;

/**
 某个像素的颜色

 @param point 像素点
 @return 颜色
 */
- (UIColor *)colorAtPixel:(CGPoint)point ;


/**
 是否含有透明通道

 @return 是否含有透明信息
 */
- (BOOL)hasAlphaChannel ;

+ (UIImage *)grayImageFromImage:(UIImage*)sourceImage ;
- (UIImage *)grayImage ;



#pragma mark - 转换#FFFFFF格式颜色

/**
 *  转换#FFFFFF格式颜色
 *
 *  @param string 颜色字符串
 *
 *  
 */
+ (UIColor *)RGBColor:(NSString *)string;

/**
 *  转换#FFFFFF格式颜色
 *
 *  @param string 颜色只付出
 *  @param alpha  指定透明
 *
 *  @return 颜色
 */
+ (UIColor *)RGBColor:(NSString *)string alpha:(CGFloat )alpha;

#pragma mark - 颜色直接生成图片
/**
 *  返回指定颜色生成的图片
 *
 *  @param color 颜色
 *  @param size  尺寸
 *  @param name  文本
 *
 *
 */
+ (UIImage *)imageWithColor:(UIColor *)color andSize:(CGSize)size text:(NSString *)name;
/**
 *  获取指定尺寸（50*50）的图片
 *
 *  @param color 图片颜色
 *  @param name  文本
 *
 *
 */
+ (UIImage *)imageWithColor:(UIColor *)color text:(NSString *)name;

+ (UIImage *)imageWithColor:(UIColor *)color andSize:(CGSize)size;


@end
