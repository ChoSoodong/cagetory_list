//
//  UIImage+CircleImage.m
//  Finance
//
//  Created by ZHAO on 2018/9/28.
//  Copyright © 2018年 HaramElectronic. All rights reserved.
//

#import "UIImage+CircleImage.h"

@implementation UIImage (CircleImage)

-(void)circleImageWithCompletion:(completion)completion{
    
    //子线程中切圆角
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        // 获取图片对象
        UIImage *img = [self circleImage];
        
        // 图片下载完成之后,回到主线程更新UI
        dispatch_async(dispatch_get_main_queue(), ^{
            // 设置图片视图
            completion(img);
            
        });
    });
    
}


- (instancetype)circleImage
{
    // 1.开启图形上下文
    // 比例因素:当前点与像素比例
    UIGraphicsBeginImageContextWithOptions(self.size, NO, 0);
    // 2.描述裁剪区域
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, self.size.width, self.size.height)];
 
   
    // 3.设置裁剪区域;
    [path addClip];
    // 4.画图片
    [self drawAtPoint:CGPointZero];
    // 5.取出图片
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    // 6.关闭上下文
    UIGraphicsEndImageContext();
    
    return image;
}

+ (instancetype)circleImageNamed:(NSString *)name
{
    return [[self imageNamed:name] circleImage];
}


- (instancetype)drawCornerRadiusWithRadius:(CGFloat)radius{
    
    CGRect rect = CGRectMake(0, 0, self.size.width, self.size.height);
    
    UIBezierPath *bezierPath = [UIBezierPath bezierPathWithRoundedRect:rect cornerRadius:self.size.width*radius];
    UIGraphicsBeginImageContextWithOptions(rect.size, false, [UIScreen mainScreen].scale);
    CGContextAddPath(UIGraphicsGetCurrentContext(), bezierPath.CGPath);
    CGContextClip(UIGraphicsGetCurrentContext());
    [self drawInRect:rect];
    
    CGContextDrawPath(UIGraphicsGetCurrentContext(), kCGPathFillStroke);
    UIImage *output = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return output;
}
+ (instancetype)drawCornerRadiusWithImageNamed:(NSString *)name radius:(CGFloat)radius{
    return [[self imageNamed:name] drawCornerRadiusWithRadius:radius];
}


-(void)drawCornerRadiusWithRadius:(CGFloat)radius completion:(completion)completion{
    
    //子线程中切圆角
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        // 获取图片对象
        UIImage *img = [self drawCornerRadiusWithRadius:radius];
        
        // 图片下载完成之后,回到主线程更新UI
        dispatch_async(dispatch_get_main_queue(), ^{
            // 设置图片视图
            completion(img);
            
        });
    });
    
}


@end
