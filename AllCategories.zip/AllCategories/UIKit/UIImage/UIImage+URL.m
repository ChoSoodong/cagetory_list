//
//  UIImage+URL.m
//  APPFlow
//
//  Created by ZHAO on 2018/6/22.
//  Copyright © 2018年 XiaLanTech. All rights reserved.
//

#import "UIImage+URL.h"

@implementation UIImage (URL)

+ (UIImage *) imageFromURLString: (NSString *) urlstring{
    
    return [UIImage imageWithData:[NSData  dataWithContentsOfURL:[NSURL URLWithString:urlstring]]];
    
    
}




@end
