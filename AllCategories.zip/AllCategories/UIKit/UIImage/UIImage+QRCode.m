//
//  UIImage+QRCode.m
//  Finance
//
//  Created by ZHAO on 2018/8/21.
//  Copyright © 2018年 HaramElectronic. All rights reserved.
//

#import "UIImage+QRCode.h"

@implementation UIImage (QRCode)

+(UIImage *)imageWithQRCodeText:(NSString *)text logoImage:(UIImage *)logoImage{
    
    // 二维码过滤器
    CIFilter *filterImage = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    // 将二位码过滤器设置为默认属性
    [filterImage setDefaults];
    // 将文字转化为二进制
    NSData *dataImage = [text dataUsingEncoding:NSUTF8StringEncoding];
    // KVC 赋值
    [filterImage setValue:dataImage forKey:@"inputMessage"];
    // 取出输出图片
    CIImage *outputImage = [filterImage outputImage];
    outputImage = [outputImage imageByApplyingTransform:CGAffineTransformMakeScale(20, 20)];
    // 转化图片
    UIImage *image = [UIImage imageWithCIImage:outputImage];
    
    // 为二维码加自定义图片
    
    // 开启绘图, 获取图片 上下文<图片大小>
    UIGraphicsBeginImageContext(image.size);
    // 将二维码图片画上去
    [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
    // 将小图片画上去
    UIImage *smallImage = logoImage;
    [smallImage drawInRect:CGRectMake((image.size.width - 60) / 2, (image.size.width - 60) / 2, 60, 60)];
    // 获取最终的图片
    UIImage *finalImage = UIGraphicsGetImageFromCurrentImageContext();
    // 关闭上下文
    UIGraphicsEndImageContext();
    // 显示
    return finalImage;
    
    
    
}

+(UIImage *)imageWithQRCodeText:(NSString *)text{
    
    // 二维码过滤器
    CIFilter *filterImage = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    // 将二位码过滤器设置为默认属性
    [filterImage setDefaults];
    // 将文字转化为二进制
    NSData *dataImage = [text dataUsingEncoding:NSUTF8StringEncoding];
    // KVC 赋值
    [filterImage setValue:dataImage forKey:@"inputMessage"];
    // 取出输出图片
    CIImage *outputImage = [filterImage outputImage];
    outputImage = [outputImage imageByApplyingTransform:CGAffineTransformMakeScale(20, 20)];
    // 转化图片
    UIImage *image = [UIImage imageWithCIImage:outputImage];
    
    // 为二维码加自定义图片
    
    // 开启绘图, 获取图片 上下文<图片大小>
    UIGraphicsBeginImageContext(image.size);
    // 将二维码图片画上去
    [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
    
    // 获取最终的图片
    UIImage *finalImage = UIGraphicsGetImageFromCurrentImageContext();
    // 关闭上下文
    UIGraphicsEndImageContext();
    // 显示
    return finalImage;
    
}

@end
