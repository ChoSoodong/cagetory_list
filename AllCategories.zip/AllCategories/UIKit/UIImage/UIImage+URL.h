//
//  UIImage+URL.h
//  APPFlow
//
//  Created by ZHAO on 2018/6/22.
//  Copyright © 2018年 XiaLanTech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (URL)


/**
 将图片url转为图片 此方法要在子线程中执行

 @param urlstring 图片的url字符串
 @return 图片
 */
+ (UIImage *) imageFromURLString: (NSString *) urlstring;

@end
