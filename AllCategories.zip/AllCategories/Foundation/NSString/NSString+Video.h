//
//  NSString+Video.h
//  KoreanPetApp
//
//  Created by xialan on 2018/12/3.
//  Copyright © 2018 HARAM. All rights reserved.
//

#import <Foundation/Foundation.h>

/**请求完成的Block*/
typedef void(^ completion)(UIImage *image);

@interface NSString (Video)


/**
 视频url字符串获取视频第一帧图片 , 异步加载
 
 @param completion 请求完成的图片
 */
-(void)URLStringToVideoScreenshotsCompletion:(completion)completion;

+(void)URLStringToVideoScreenshotsWithUrlString:(NSString *)url completion:(completion)completion;

@end


