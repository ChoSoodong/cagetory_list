




#ifndef FoundationHeader_h
#define FoundationHeader_h



#import "NSNumber+Roman.h"
#import "NSNumber+Round.h"
#import "NSNumber+Display.h"
#import "NSNumber+Format.h"
#import "NSNumber+Add.h"



#import "NSString+AppInfo.h"
#import "NSString+Hash.h"
#import "NSString+Size.h"
#import "NSString+Contains.h"
#import "NSString+Regex.h"
#import "NSString+VersionCompare.h"
#import "NSString+Extend.h"
#import "NSString+Category.h"
#import "NSString+Image.h"
#import "NSString+Video.h"
#import "NSString+QRcode.h"
#import "NSString+URL.h"

#import "NSDictionary+JsonString.h"

#import "NSObject+LinearFormula.h"


#endif

