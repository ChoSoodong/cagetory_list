//
//  NSNumber+Format.h
//
//
//  Created by xialan on 2019/2/16.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSNumber (Format)

/**
 *  @brief 格式化数字，如10000 -> 10,000
 */
- (NSString *)stringFromDecimalStyleNumber;


@end


