//
//  NSNumber+Add.m
//  AlphaPay
//
//  Created by xialan on 2019/2/22.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import "NSNumber+Add.h"

@implementation NSNumber (Add)


- (NSString *)lf_wrappedDescription {
    if (self.longLongValue <= 9999) {
        return self.description;
    } else {
        return [NSString stringWithFormat:@"%.1f万",(self.longLongValue)/(10000.0)];
    }
}


- (NSString *)lf_toDecimalStyleString
{
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    numberFormatter.numberStyle = NSNumberFormatterDecimalStyle;
    return [numberFormatter stringFromNumber:self];
}


@end
