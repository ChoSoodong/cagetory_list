//
//  NSNumber+Format.m
//
//
//  Created by xialan on 2019/2/16.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import "NSNumber+Format.h"

@implementation NSNumber (Format)


- (NSString *)stringFromDecimalStyleNumber
{
    static NSNumberFormatter *numberFormatter = nil;
    if (numberFormatter == nil) {
        numberFormatter = [[NSNumberFormatter alloc] init];
        [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    }
    return [numberFormatter stringFromNumber:self];
}


@end
