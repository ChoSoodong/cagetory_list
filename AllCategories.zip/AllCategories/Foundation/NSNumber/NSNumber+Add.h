//
//  NSNumber+Add.h
//  AlphaPay
//
//  Created by xialan on 2019/2/22.
//  Copyright © 2019 HARAM. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSNumber (Add)


/**
 如果超出9999，则折叠成 XX.X 万
 */
- (NSString *)sd_wrappedDescription;

- (NSString *)sd_toDecimalStyleString;



@end

NS_ASSUME_NONNULL_END
