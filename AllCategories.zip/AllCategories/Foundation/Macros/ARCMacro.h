




// 强弱引用
#define WeakSelf          __weak __typeof(self) weakSelf = self;
#define StrongSelf        __strong __typeof(weakSelf)strongSelf = weakSelf;
