



// 加载本地字符串
#ifndef LOCALIZED_STRING
#define LOCALIZED_STRING(string)                NSLocalizedString(string, nil)
#else
#pragma message("LOCALIZED_STRING already declared")
#endif

#define LANG                                        LOCALIZED_STRING(@"globals.lang")
#define LANG_DISPLAY                                LOCALIZED_STRING(@"globals.langDisplay")

//拼接字符串
#define NSStringFormat(format,...) [NSString stringWithFormat:format,##__VA_ARGS__]

// 单例对象
#define NOTIFICATION_CENTER                         [NSNotificationCenter defaultCenter]
#define FILE_MANAGER                                [NSFileManager defaultManager]
#define MAIN_BUNDLE                                 [NSBundle mainBundle]
#define MAIN_THREAD                                 [NSThread mainThread]
#define MAIN_SCREEN                                 [UIScreen mainScreen]
#define USER_DEFAULTS                               [NSUserDefaults standardUserDefaults]
#define APPLICATION                                 [UIApplication sharedApplication]
#define CURRENT_DEVICE                              [UIDevice currentDevice]
#define MAIN_RUN_LOOP                               [NSRunLoop mainRunLoop]
#define GENERAL_PASTEBOARD                          [UIPasteboard generalPasteboard]
#define KEY_WINDOW                                  [[UIApplication sharedApplication] keyWindow]

// 字体
#define FONT(size)                                  [UIFont systemFontOfSize:size]
#define BOLD_FONT(size)                             [UIFont boldSystemFontOfSize:size]
///** 字体自适应 */
//#define IOS_VERSION_10_OR_LATER (([[[UIDevice currentDevice]systemVersion]floatValue]>=10.0)? (YES):(NO))
//#define AdapationFont(n) (IOS_VERSION_10_OR_LATER?((n-1)*([[UIScreen mainScreen]bounds].size.width/375.0f)):((n)*([[UIScreen mainScreen]bounds].size.width/375.0f)))

// 判断字符串是否为空
#define IsEmptyString(s) (s == nil || [s isKindOfClass:[NSNull class]] || ([s isKindOfClass:[NSString class]] && s.length == 0))
// 判断对象是否为空
#define IsEmptyObject(obj) (obj == nil || [obj isKindOfClass:[NSNull class]])
//判断字典是否为空
#define IsDictionary(objDict) (objDict != nil && [objDict isKindOfClass:[NSDictionary class]])
//判断数组是否为空
#define IsArray(objArray) (objArray != nil && [objArray isKindOfClass:[NSArray class]])


// 网络
#define NETWORK_ACTIVITY                            [APPLICATION networkActivityIndicatorVisible]

// 归档
#define OBJECT2DATA(object)   [NSKeyedArchiver archivedDataWithRootObject:object]
#define DATA2OBJECT(data)     [NSKeyedUnarchiver unarchiveObjectWithData:data]

// Application信息
#define APPLICATION_NAME                            [MAIN_BUNDLE objectForInfoDictionaryKey:@"CFBundleDisplayName"]
#define APPLICATION_VERSION                         [MAIN_BUNDLE objectForInfoDictionaryKey:@"CFBundleShortVersionString"]
#define APPLICATION_BUILD_VERSION                   [MAIN_BUNDLE objectForInfoDictionaryKey:@"CFBundleVersion"]
#define APPLICATION_BUNDLE_ID                       [MAIN_BUNDLE objectForInfoDictionaryKey:@"CFBundleIdentifier"]

//设置屏幕亮度
#define DECVICE_BRIGHTNESS(brightness) [[UIScreen mainScreen] setBrightness:brightness];
//设置屏幕常亮
#define DECVICE_NORMALLYON(isNornallyOn)   [[UIApplication sharedApplication] setIdleTimerDisabled:isNornallyOn];

// USER_DEFAULTS
#define USER_DEFAULTS                               [NSUserDefaults standardUserDefaults]
#define USER_DEFAULTS_SET_OBJECT_FOR_KEY(__VALUE__,__KEY__) \
{\
[[NSUserDefaults standardUserDefaults] setObject:__VALUE__ forKey:__KEY__];\
[[NSUserDefaults standardUserDefaults] synchronize];\
}
#define USER_DEFAULTS_OBJECT_FOR_KEY(__KEY__)  [[NSUserDefaults standardUserDefaults] objectForKey:__KEY__]
#define USER_DEFAULTS_REMOVE_OBJECT_FOR_KEY(__KEY__) \
{\
[[NSUserDefaults standardUserDefaults] removeObjectForKey:__KEY__];\
[[NSUserDefaults standardUserDefaults] synchronize];\
}

